

// L�put��
// Oliver-Hendrik Hermlin

#include <stdio.h>

// Globaalsed muutujad
	char menuu;
	char raskustase;
	int mang;
	int summa;
	const char* sonum;
	int skoor = 0;
// Funktsioonide deklaratsioonid
void skoor_loe();
void skoor_salvesta();
void mangima();
void kontroll();


int main() {
	
skoor_loe();
srand(time(NULL)); //genereerib igakord uue numbri
	
while(1) {


	printf("-------------------------------\n");
	printf("Numbrijaht!\n");
	printf("Sinu praegune skoor: %d\n", skoor);
	printf("(sisesta sulgudes olev taht, et menuus navigeerida)\n");
	printf("\n");
	printf("-------------------------------\n");
	printf("Mangujuhend (d)\n");
	printf("Alusta manguga? (s)\n");
	printf("-------------------------------\n");
  	scanf(" %c", &menuu); //sisestus

if (menuu == 'd') { // M�ngujuhend

	printf("-------------------------------\n");
	printf("Mang on usna lihtne! Sinu ulesandeks on ara arvata, mis arvu arvuti parajasti motleb. Siia on sisseehiatud kolm raskustaset: kerge (1-5), keskmine (1-10) ja raske (1-15). Kui oled valmis alustama mangimisega, sisesta (s)\n");

}

else if (menuu == 's') { // Raskustase

	printf("-------------------------------\n");
	printf("Vali raskustase\n");
	printf("Kerge (e)\n");
	printf("Keskmine (k)\n");
	printf("Raske (r)\n");
	printf("-------------------------------\n");
	scanf(" %c", &raskustase);
}



switch (raskustase) { // Switch selektor

case 'e': // lihtne
	mang = rand() % 5 + 1; // 1-5 Genereeritud Number ja salvestab muutujasse
	sonum = "Mis arvu peale ma voiksin moelda 1-5?\n"; // Sonum mis valjastab manguajal ekraanile
	mangima(); // kaivitab mangu
	break;
	
case 'k': // keskmine
	mang = rand() % 10 + 1; // 1-10 Genereeritud Number ja salvestab muutujasse
	sonum = "Mis arvu peale ma voiksin moelda 1-10?\n"; // Sonum mis valjastab manguajal ekraanile
	mangima();
	break;

case 'r': // raske
	mang = rand() % 15 + 1; // 1-15 Genereeritud Number ja salvestab muutujasse
	sonum = "Mis arvu peale ma voiksin moelda 1-15?\n"; // Sonum mis valjastab manguajal ekraanile
	mangima(); // kaivitab mangu
	break;
default: // Kui kasutaja sisestab midagi muud
	printf("Vale sisestus\n");
	 break;
	
	}
  }
}
// funktsioonid
void skoor_loe() {
		FILE *skooring = fopen("skoor.txt", "r"); // loeb
		if (skooring == NULL) { // loob skoor.txt juhul kui seda ei leita
			skooring = fopen("skoor.txt", "w");
	} 
	else {
		fscanf(skooring, "%d", &skoor); // loeb/margib tekstis olevat numbrit skooriks
		fclose(skooring);
	}	
}
void skoor_salvesta() { 
	FILE *skooring = fopen("skoor.txt", "w"); //kirjutab skoori umber
	fprintf(skooring, "%d", skoor); // kirjutab skoori faili
	fclose(skooring); 
}
void mangima() { // M�ngup�hi funktsioon
  	printf("--------- Sinu mang algas ------------\n"); 
  	printf("\n");
    printf("%s", sonum); // Raskustase 
    scanf("%d", &summa); // K�sib kasutajalt numbrit
    kontroll(); // K�ivitab kontrolli
	
}
void kontroll() { // Kontrollib sisestatud numbrit
	if (mang == summa) {
	   	printf("-------------------------------\n");
	   printf("Palju Onne! Arvasid ara mu keerulise numbri.\n"); // Kood oli t�pselt sama mis kasutaja omagi
	   skoor++;
	   skoor_salvesta();
}
	else {
		printf("-------------------------------\n");
		printf("Vale, oige number oli %d\n", mang); // Sisestatud number oli vale ja programm utleb oige numbri
	}
	
}
